class CreateProducts < ActiveRecord::Migration[7.1]
  def change
    create_table :products do |t|
      t.string  :era, null: false
      t.string  :set_name, null: false
      t.string  :product_type, null: false
      t.integer :value_cents, null: false, default: 0
      t.timestamps
    end
    add_index :products, %i[era set_name product_type]
  end
end