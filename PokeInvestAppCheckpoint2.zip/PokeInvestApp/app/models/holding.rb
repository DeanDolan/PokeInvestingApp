class Holding < ApplicationRecord
  belongs_to :user
  belongs_to :product

  validates :quantity, numericality: { only_integer: true, greater_than: 0 }
  validates :cost_per_unit_cents, numericality: { only_integer: true, greater_than_or_equal_to: 0 }

  def total_cost_cents
    quantity * cost_per_unit_cents
  end

  def value_per_unit_cents
    product.value_cents
  end

  def total_value_cents
    quantity * value_per_unit_cents
  end

  def pl_cents
    total_value_cents - total_cost_cents
  end

  def roi_percent
    return nil if cost_per_unit_cents.zero?
    (value_per_unit_cents.to_f / cost_per_unit_cents * 100.0)
  end
end