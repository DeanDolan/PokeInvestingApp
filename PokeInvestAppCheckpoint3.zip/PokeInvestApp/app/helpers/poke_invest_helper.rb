module PokeInvestHelper
end
