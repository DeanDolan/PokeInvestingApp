class User < ApplicationRecord
  has_many :holdings, dependent: :destroy
end