class HoldingsController < ApplicationController
  before_action :set_holding, only: %i[show edit update destroy]

  def index
    @holdings = current_user.holdings.includes(:product).order(created_at: :desc)
  end

  def show; end

  def new
    @holding  = current_user.holdings.new
    @products = Product.order(:era, :set_name, :product_type)
  end

  def edit
    @products = Product.order(:era, :set_name, :product_type)
  end

  def create
    @holding = current_user.holdings.new(holding_params)
    if @holding.save
      redirect_to @holding, notice: "Holding created."
    else
      @products = Product.order(:era, :set_name, :product_type)
      render :new, status: :unprocessable_entity
    end
  end

  def update
    if @holding.update(holding_params)
      redirect_to @holding, notice: "Holding updated."
    else
      @products = Product.order(:era, :set_name, :product_type)
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @holding.destroy
    redirect_to holdings_url, notice: "Holding deleted."
  end

  private

  def set_holding
    @holding = current_user.holdings.find(params[:id])
  end

  def holding_params
    params.require(:holding).permit(:product_id, :quantity, :cost_per_unit_cents)
  end
end
