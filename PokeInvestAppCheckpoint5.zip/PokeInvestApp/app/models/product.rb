class Product < ApplicationRecord
  has_many :holdings, dependent: :restrict_with_exception

  PRODUCT_TYPES = [
    "Booster Box",
    "Enhanced Booster Box",   # directly below Booster Box
    "Booster Bundle",
    "Booster Bundle Display",
    "UPC/SPC",
    "Elite Trainer Box"
  ].freeze

  validates :era, :set_name, :product_type, presence: true
  validates :product_type, inclusion: { in: PRODUCT_TYPES }
  validates :value_cents, numericality: { only_integer: true, greater_than_or_equal_to: 0 }

  def title
    "#{era} | #{set_name} | #{product_type}"
  end

  # Virtual € attribute mapped to *_cents
  def value_eur
    return nil if value_cents.nil?
    (value_cents.to_f / 100.0).round(2)
  end

  def value_eur=(input)
    cents = self.class.euros_to_cents(input)
    self.value_cents = cents unless cents.nil?
  end

  # Robust parsing for "34.99", "34,99", "€34.99"
  def self.euros_to_cents(input)
    return nil if input.nil?
    s = input.to_s.strip
    return nil if s.empty?
    s = s.tr(",", ".").gsub(/[^\d.]/, "")
    return nil if s.empty? || s == "."
    (BigDecimal(s) * 100).round(0).to_i
  rescue ArgumentError
    nil
  end
end