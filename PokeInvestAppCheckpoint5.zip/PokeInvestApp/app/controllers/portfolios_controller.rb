class PortfoliosController < ApplicationController
  def show
    holdings = current_user.holdings.includes(:product)
    @total_cost_cents  = holdings.sum(&:total_cost_cents)
    @total_value_cents = holdings.sum(&:total_value_cents)
    @pl_cents          = @total_value_cents - @total_cost_cents
    @roi_percent       = @total_cost_cents.positive? ? (@total_value_cents.to_f / @total_cost_cents * 100.0) : nil
  end
end