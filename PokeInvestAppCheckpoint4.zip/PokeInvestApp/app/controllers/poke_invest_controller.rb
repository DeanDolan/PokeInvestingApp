class PokeInvestController < ApplicationController
end
