user = User.find_or_create_by!(name: "Demo User")

base_set_box  = Product.find_or_create_by!(era: "WOTC", set_name: "Base Set", product_type: "Booster Box", value_cents: 120_000)
bundle_disp   = Product.find_or_create_by!(era: "Scarlet & Violet", set_name: "Obsidian Flames", product_type: "Booster Bundle Display", value_cents: 18_000)
upc_spc       = Product.find_or_create_by!(era: "Sword & Shield", set_name: "Celebrations", product_type: "UPC/SPC", value_cents: 35_000)
etb           = Product.find_or_create_by!(era: "Scarlet & Violet", set_name: "151", product_type: "Elite Trainer Box", value_cents: 5_000)
bundle        = Product.find_or_create_by!(era: "Scarlet & Violet", set_name: "Paradox Rift", product_type: "Booster Bundle", value_cents: 3_200)

Holding.find_or_create_by!(user:, product: etb,     quantity: 2, cost_per_unit_cents: 4_500)
Holding.find_or_create_by!(user:, product: bundle,  quantity: 5, cost_per_unit_cents: 3_000)
